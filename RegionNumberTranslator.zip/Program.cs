﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;

namespace RegionNumberTranslator
{
    public class Program
    {
        static void Main(string[] args)
        {
            //load region file
            Tools.GetRegions("NYC_862.txt");
            int i = 0;
            //string filePath = "C:\\Users\\fander\\Desktop\\graphhopper-master\\2014_yellow_10.csv_time33.txt"; // 替换为实际的文件路径
            string filePath = "C:\\Users\\fander\\Desktop\\graphhopper-master\\test.txt"; // 替换为实际的文件路径
            List<DataEntry> parsedData = ReadCsvFromFile(filePath);
            foreach (var entry in parsedData)
            {
                Console.WriteLine($"Start Time: {entry.StartTime}, End Time: {entry.EndTime}, Value: {entry.Value},Value2:{entry.Value2},Value3:{entry.Value3}");
                i += 1;
            }
            //Console.ReadLine();
            Console.WriteLine(i);
            //return region numbers, 0 to 861
            int[] region = Tools.GetRegionNumber(double.Parse(args[0]), double.Parse(args[1]));
            int jiang = 1998;
            Console.WriteLine(region[0]);
            Console.WriteLine("hello123");
            Console.ReadKey();
        }
        static List<DataEntry> ReadCsvFromFile(string filePath)
        {
            int i = 0;
            List<DataEntry> entries = new List<DataEntry>();
            try
            {
                using (StreamReader sr = new StreamReader(filePath))
                {
                    string line;
                    while ((line = sr.ReadLine()) != null)
                    {
                        string[] parts = line.Split(',');
                        
                        if (parts.Length == 5)
                        {
                            i += 1;
                            DateTime startTime = DateTime.ParseExact(parts[0], "yyyy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture);
                            DateTime endTime = DateTime.ParseExact(parts[1], "yyyy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture);
                            double value = double.Parse(parts[2], CultureInfo.InvariantCulture);
                            double value2 = double.Parse(parts[3], CultureInfo.InvariantCulture);
                            double value3 = double.Parse(parts[4], CultureInfo.InvariantCulture);

                            DataEntry entry = new DataEntry { StartTime = startTime, EndTime = endTime, Value = value,Value2=value2,Value3=value3 };
                            entries.Add(entry);
                        }

                    }
                }
            }
            catch (Exception ex)
            {Console.WriteLine($"Error reading file: {ex.Message}"); }
            Console.WriteLine(i);
            return entries;
        }


    }
}

class DataEntry
{
    public DateTime StartTime { get; set; }
    public DateTime EndTime { get; set; }
    public double Value { get; set; }
    public double Value2 { get; set; }
    public double Value3 { get; set; }
}


/*class Program
{
    static void Main()
    {
        string filePath = "your_file_path.csv"; // 替换为实际的文件路径

        List<DataEntry> parsedData = ReadCsvFromFile(filePath);

        foreach (var entry in parsedData)
        {
            Console.WriteLine($"Start Time: {entry.StartTime}, End Time: {entry.EndTime}, Value: {entry.Value}");
        }

        Console.ReadLine();
    }

    static List<DataEntry> ReadCsvFromFile(string filePath)
    {
        List<DataEntry> entries = new List<DataEntry>();

        try
        {
            using (StreamReader sr = new StreamReader(filePath))
            {
                string line;
                while ((line = sr.ReadLine()) != null)
                {
                    string[] parts = line.Split(',');

                    if (parts.Length == 3)
                    {
                        DateTime startTime = DateTime.ParseExact(parts[0], "yyyy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture);
                        DateTime endTime = DateTime.ParseExact(parts[1], "yyyy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture);
                        double value = double.Parse(parts[2], CultureInfo.InvariantCulture);

                        DataEntry entry = new DataEntry { StartTime = startTime, EndTime = endTime, Value = value };
                        entries.Add(entry);
                    }
                }
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Error reading file: {ex.Message}");
        }

        return entries;
    }
}

    */